## Requirements

| Name | Version |
|------|---------|
| terraform | >=0.14.10 |
| azurecaf | 1.1.3 |
| azurerm | >=2.55.0 |

## Providers

| Name | Version |
|------|---------|
| azurecaf | 1.1.3 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| apmid | APMID used during the name generation | `string` | n/a | yes |
| certifiedProductName | Name of the certified product as listed in the CCoE product catalog (i.e. sql-managed-instance) | `string` | n/a | yes |
| serviceName | Specifies the name of the service , layer, or other descriptive name | `string` | n/a | yes |
| suffix | Suffix to be added to the resource name | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| result | Automatically generated name |

